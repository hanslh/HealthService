<template>
	<v-container class="mt-5">
		<v-layout>
			<v-flex xs6 text-xs-center>
				<v-card
					color="blue">
					<h1>Main Page!!</h1>
				</v-card>
			</v-flex>
			<v-flex xs6 text-xs-center>
				<h1>Main Page!!</h1>
			</v-flex>
		</v-layout>

		<v-layout>
			<v-flex xs12>
				<v-btn>Knapp</v-btn>
			</v-flex>
		</v-layout>
	</v-container>
</template>

<script>
	
</script>

<style scoped>

</style>