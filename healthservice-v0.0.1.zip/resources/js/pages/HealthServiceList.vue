<template>
	<v-container>
		<v-layout>
			<v-flex xs12 text-xs-center>
				<span class="display-2">Liste over helseforetak</span>
			</v-flex>
		</v-layout>

		<v-layout>
			<v-flex xs12 text-xs-center>
				<v-btn @click="getHealthServices">Hent liste</v-btn>
			</v-flex>
		</v-layout>

		<v-layout>
			<v-flex xs12 text-xs-center>
				<span v-if="loadState === 1" class="">Henter liste...</span>
				<span v-if="loadState === 2" class="">Lasting av liste ferdig</span>
				<span v-if="loadState === 3" class="">Lasting av liste feilet</span>
			</v-flex>
		</v-layout>

		<v-card>
		<v-card-text class="pa-0">
			<v-list dense three-line class="ma-0 pa-0">
		        <div v-for="(service, index) in services" :key="service.OrganizationNumber">

		            <v-list-tile @click="serviceSelected(index)">

		        	    <v-list-tile-avatar
                            class="mt-1"
                            :tile="true">
		        	        <img src="redcross.png"/>
		        	    </v-list-tile-avatar>
		        	    
		        	    <v-list-tile-content>
		        	        <v-list-tile-title class="">{{ service.DisplayName }}</v-list-tile-title>
		        	        <v-list-tile-sub-title class="">{{ service.CountyName }}</v-list-tile-sub-title>
		        	        <v-list-tile-sub-title class="">{{ service.OpeningHours }}</v-list-tile-sub-title>
		        	    </v-list-tile-content>
		        	    
		        	    <v-list-tile-action>
		        	    	<v-icon color="">
		        	    		assignment
		        	    	</v-icon>
		        	    	<v-list-tile-action-text>
		        	    		TBD
		        	    	</v-list-tile-action-text>
		        	    </v-list-tile-action>

		            </v-list-tile>

		            <v-divider inset></v-divider>

		        </div>
		    </v-list>
		    
		    <v-list dense v-if="servicesLength" class="endofcontent">
		    	 <v-list-tile>
					<v-list-tile-content>
						Siste Oppføring
					</v-list-tile-content>
				</v-list-tile>
		    </v-list>

		    <v-list v-if="!servicesLength" class="endofcontent">
		    	 <v-list-tile>
					<v-list-tile-content>
						{{ emptyText }}
					</v-list-tile-content>
				</v-list-tile>
		    </v-list>

		</v-card-text>
	</v-card>

	</v-container>
</template>

<script>
	export default{
		data(){
			return{
				loadState: 0,
				// 0 Init
				// 1 Loading started
				// 2 Loading successful
				// 3 Loading error

				services: [],
				length: 10,
				latitude: 59.931,
				longitude: 10.318,
				emptyText: 'Listen er tom'
			}
		},
		computed:{
			servicesLength(){
				return this.services.length;
			}
		},
		methods:{
			serviceSelected(index){
				console.log(index);
			},
			getHealthServices(){
				// Load repositories from github API
				this.loadState = 1;

				axios.get('http://data.helsenorge.no/healthservices?$top=' + this.length + '&latitude=' + this.latitude + '&longitude=' + this.longitude)
					.then(response => {
						console.log(response.data);
						// Loading successful
						this.loadState = 2;
						this.services = response.data;
					})
					.catch(error => {
						// Loading error
						this.loadState = 3;
						console.log(error);
					});
			}
		}
	}
</script>

<style scoped>

</style>