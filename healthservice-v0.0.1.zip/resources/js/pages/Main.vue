<template>
	<v-container class="mt-5">
		<v-layout>
			<v-flex xs12 text-xs-center>
				<span class="display-2">Finn nærmeste helsetjeneste</span>
			</v-flex>
		</v-layout>

		<v-layout class="my-3">
			<v-flex xs12>
				<GoogleMap></GoogleMap>
			</v-flex>
		</v-layout>

		<v-layout>
			<v-flex xs12 text-xs-center>
				<v-btn 
					router 
					:to="{ name: 'HealthServiceList'}">
					Knapp
				</v-btn>
			</v-flex>
		</v-layout>

	</v-container>
</template>

<script>
	import GoogleMap from '../components/GoogleMap.vue';

	export default{
		components:{
			GoogleMap
		}
	}
</script>

<style scoped>

</style>