<template>
	<div id="map" style="width: 800px; height: 600px; margin: 0 auto; background: gray;"></div>
</template>

<script>
	export default{
		data(){
			return{
				initialZoom: 15,
				centerCoordinates: {
					latitude: 51.501527,
    				longitude: -0.1921837
				},
			}
		},
		mounted(){
			this.$map = new google.maps.Map(document.getElementById('map'), {
	        	center: {
	        		lat: this.centerCoordinates.latitude, 
	        		lng: this.centerCoordinates.longitude
	        	},
	        	zoom: this.initialZoom
	      	});
	
			this.$bounds = new google.maps.LatLngBounds;
	
	      	this.$geocoder = new google.maps.Geocoder;
	
	      	this.$distanceService = new google.maps.DistanceMatrixService;
		}
	}
</script>

<style scoped>

</style>